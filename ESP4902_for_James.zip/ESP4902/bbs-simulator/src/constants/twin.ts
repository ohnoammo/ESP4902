// Digital twin constants, from the team's calibration (WS7040, 15 V, runs 13–22) and CFD.
// Fixed values: do not tune them here. The firmware carries the same tables; the app uses them
// only to simulate the twin in demo mode and to label the page.

// Operating points: fan connected to the body. Linear interpolation between points.
//   RPM column: MEASURED, free delivery, runs 13–22.
//   Q columns: CALCULATED, not measured. For each rpm the WS7040 datasheet fan curve is scaled
//   by the affinity laws (Q ∝ rpm, P ∝ rpm²), flow × k (1.036), and intersected with the CFD
//   system curve; the intersection is the operating point.
//   k = 1.036 from testo 425 runs 13–22 (n = 10), measured at free delivery and assumed to hold
//   at the operating points (system dP < 7 % of the fan's shut-off pressure at each speed).
//   Not yet validated with the body attached (connected rpm = free rpm; connected flows).
export const OP_DUTY = [25, 30, 35, 40, 50, 60, 70, 80, 90, 100];
export const OP_RPM = [3185, 4570, 5843, 6920, 8800, 10750, 13001, 15107, 17236, 19383];
export const OP_Q_IN = [30.3, 43.2, 55.3, 65.6, 83.7, 102.4, 124.1, 144.5, 165.1, 185.8];
export const OP_Q_EX = [28.3, 40.5, 51.7, 61.3, 78.2, 95.7, 115.9, 134.9, 154.0, 173.4];

// Below this duty the calibration isn't validated (rows report valid = false).
export const TWIN_VALID_MIN_DUTY = 40;

// CFD system curves dP = a·Q^n (Pa, Q in L/min); laminar below 30, k-ω above 45, blend between.
const CURVES = {
  inhale: { lam: [0.0069, 1.811], tur: [0.00714, 1.854] },
  exhale: { lam: [0.01777, 1.737], tur: [0.01553, 1.833] },
} as const;
const BLEND_LO = 30;
const BLEND_HI = 45;

export type TwinDirection = 'inhale' | 'exhale';

export function interp(x: number, xs: number[], ys: number[]): number {
  if (x <= xs[0]) return ys[0];
  for (let i = 0; i < xs.length - 1; i++) {
    if (x <= xs[i + 1]) return ys[i] + ((x - xs[i]) / (xs[i + 1] - xs[i])) * (ys[i + 1] - ys[i]);
  }
  return ys[ys.length - 1];
}

export function dpSystem(q: number, dir: TwinDirection): number {
  if (q <= 0) return 0;
  const { lam, tur } = CURVES[dir];
  const L = lam[0] * q ** lam[1];
  const T = tur[0] * q ** tur[1];
  if (q <= BLEND_LO) return L;
  if (q >= BLEND_HI) return T;
  const w = (q - BLEND_LO) / (BLEND_HI - BLEND_LO);
  return (1 - w) * L + w * T;
}

const opQ = (dir: TwinDirection) => (dir === 'inhale' ? OP_Q_IN : OP_Q_EX);

// Target flow -> feed-forward duty. Below the first operating point the fan is off (no data).
export const dutyForFlow = (q: number, dir: TwinDirection) => (q < opQ(dir)[0] ? 0 : interp(q, opQ(dir), OP_DUTY));
export const rpmForDuty = (d: number) => (d <= 0 ? 0 : interp(d, OP_DUTY, OP_RPM));
// Below the first point there's no data: Q ∝ rpm (affinity law) down to 0, not the table's
// first flow (which would report 30 L/min from a nearly stopped fan). Same as the firmware.
export const flowForRpm = (rpm: number, dir: TwinDirection) =>
  rpm <= 0 ? 0 : rpm < OP_RPM[0] ? (opQ(dir)[0] * rpm) / OP_RPM[0] : interp(rpm, OP_RPM, opQ(dir));

// Max deliverable flow per direction (100 % duty).
export const Q_MAX_IN = OP_Q_IN[OP_Q_IN.length - 1];
export const Q_MAX_EX = OP_Q_EX[OP_Q_EX.length - 1];

// Q_peak = π·Vt·bpm (L/min) for a sinusoid at I:E 1:1.
export const peakFlow = (vtL: number, bpm: number) => Math.PI * vtL * bpm;

// Breathing presets (ICRP 66 unless noted). TEAM TO CONFIRM the ICRP values; keep them here only.
export interface TwinPreset {
  key: string;
  name: string;
  vt: number; // L
  bpm: number;
}
export const TWIN_PRESETS: TwinPreset[] = [
  { key: 'light-f', name: 'Light exercise, female', vt: 0.992, bpm: 21 },
  { key: 'light-m', name: 'Light exercise, male', vt: 1.25, bpm: 20 },
  { key: 'heavy-f', name: 'Heavy exercise, female', vt: 1.364, bpm: 33 },
  { key: 'heavy-m', name: 'Heavy exercise, male', vt: 1.92, bpm: 26 },
];
export const TWIN_PRESET_SOURCE = 'ICRP 66';

export const VT_RANGE = { min: 0.3, max: 2.5, step: 0.01 };

// What a flow breath's peak can be (operating points, both halves, I:E 1:1). The limit is on
// peak = pi * VE = pi * Vt * bpm, so Vt and bpm have no fixed ranges of their own.
export const PEAK_FAN_OFF = OP_Q_IN[0];        // 30.3: below this the fan is off (no data below 25 %)
export const PEAK_VALID_MIN = OP_Q_IN[3];      // 65.6: 40 % duty on the inhale fan (exhale is lower)
export const PEAK_VALID_MAX = Q_MAX_EX;        // 173.4: exhale fan at 100 % duty

// off: the fan wouldn't run; unvalidated: runs, below the calibrated 40 % duty;
// valid: inside the calibration; saturates: above the exhale fan's maximum, peak clipped.
export type PeakStatus = 'off' | 'unvalidated' | 'valid' | 'saturates';
export function peakStatus(qPeak: number): PeakStatus {
  if (qPeak < PEAK_FAN_OFF) return 'off';
  if (qPeak < PEAK_VALID_MIN) return 'unvalidated';
  return qPeak > PEAK_VALID_MAX ? 'saturates' : 'valid';
}

export const PEAK_STATUS_LABEL: Record<PeakStatus, string> = {
  off: 'Fan off: peak too low',
  unvalidated: 'Runs, not validated',
  valid: 'Validated',
  saturates: 'Peak clipped',
};

export interface FlowCheck {
  ve: number; // L/min
  peak: number; // L/min
  status: PeakStatus;
  validVt: [number, number] | null; // Vt range that's validated at this rate (within VT_RANGE)
  message: string | null; // null when validated
}

// Everything the editor and Ready screen say about a flow breath.
export function flowCheck(vt: number, bpm: number): FlowCheck {
  const ve = vt * bpm;
  const peak = Math.PI * ve;
  const status = peakStatus(peak);
  const lo = Math.max(VT_RANGE.min, PEAK_VALID_MIN / Math.PI / bpm);
  const hi = Math.min(VT_RANGE.max, PEAK_VALID_MAX / Math.PI / bpm);
  const validVt: [number, number] | null = lo <= hi ? [lo, hi] : null;
  const range = validVt ? ` At ${bpm} bpm, Vt ${validVt[0].toFixed(2)}–${validVt[1].toFixed(2)} L is validated.` : '';
  const message =
    status === 'off'
      ? `Peak ${peak.toFixed(0)} L/min is below ${PEAK_FAN_OFF} L/min, where the fan doesn't run.${range}`
      : status === 'unvalidated'
        ? `Peak ${peak.toFixed(0)} L/min runs, but below ${PEAK_VALID_MIN} L/min (40 % duty) the fan calibration isn't validated.${range}`
        : status === 'saturates'
          ? `Peak ${peak.toFixed(0)} L/min is above the exhale fan's ${PEAK_VALID_MAX} L/min maximum, so the peak will be clipped.${range}`
          : null;
  return { ve, peak, status, validVt, message };
}

// The twin's peak feed-forward duty for a flow breath (inhale fan), for the duty band and runs.duty.
export const flowPeakDuty = (vt: number, bpm: number) =>
  Math.round(Math.min(100, dutyForFlow(Math.min(Math.PI * vt * bpm, Q_MAX_IN), 'inhale')));

// Flow that a duty gives at the operating points (inhale fan), to convert old duty presets.
export const flowForDuty = (duty: number) => (duty < OP_DUTY[0] ? OP_Q_IN[0] : interp(duty, OP_DUTY, OP_Q_IN));

// RPM trim: duty correction limit; at the limit the fan can't reach the speed (fault 2).
export const TRIM_LIMIT = 10;

// telemetry.fault. Only faults the rpm can show; leak/blockage codes are reserved for when a
// pressure sensor is added.
export type TwinFault = 0 | 1 | 2 | 3 | 4; // ok, fan not spinning, trim saturated, leak, blockage
export const FAULT_LABEL: Record<TwinFault, string> = { 0: 'OK', 1: 'No spin', 2: 'Trim at limit', 3: 'Leak', 4: 'Blockage' };

// The page's "Where these numbers come from" text, kept beside the tables it describes.
export const TWIN_SOURCES = [
  'Blower rpm is the only measurement (tach, 1 pulse per rev). There is no flow or pressure sensor.',
  'Twin flow is the operating-point flow at the measured rpm. The rpm column is measured (free delivery, runs 13–22); the flow columns are calculated: datasheet fan curve scaled by the affinity laws, × 1.036, intersected with the CFD system curve.',
  'k = 1.036 is from testo 425 runs 13–22 (n = 10), worst case +2.4 % / −2.0 %, valid at duty ≥ 40 %. It was measured at free delivery and is assumed to hold on the body (system dP is under 7 % of the fan’s shut-off pressure).',
  'Not yet validated with the body attached: connected rpm = free rpm, and the connected flows.',
  'The rpm trim corrects duty so the measured rpm matches the expected rpm, and keeps what it learns between breaths (e.g. for battery sag).',
];
